<?php
    namespace App\Http\Controllers;

    use Illuminate\Http\Request;
    use App\Models\Account\Signin;
    use App\Models\Account\Signup;
    use App\Models\Account\OnetimePass;
    use App\Models\Session\Session;

    use Log;

    class AccountController extends Controller{
        public function __construct (){
            $user_id = Session::get("user_id");
            $user_token = Session::get ("user_token");
            if ($user_id === false || $user_token === false){
                return;
            }
            if (Signin::token ($user_id, $user_token)){
                redirect ()->to ("information");
            }
        }
        public function get (Request $req){
            // Base a screen selector
            $opt = $this::setOpt ();
            switch ($opt){
                case ("signin"):
                    return view ("account.signin");
                case ("signup"):
                    return view ("account.signup");
                case ("onetimepass"):
                    return view ("account.onetimepassword");
            }
            return view ("account.signin");
        }
        public function post (Request $req){
            try{
                $opt = $this::setOptPost ();
                switch ($opt){
                    case ("signin"):
                        return redirect ()->to ("account");
                    case ("signup"):
                        
                        if (!isset ($_POST["email"])){
                            // Unset email
                            return redirect ()->to ("account");
                        }
                        if (!Signup::sendEmail ($_POST["email"])){
                            return redirect ()->to ("account?opt=signup");
                        }
                        return redirect ()->to ("account?opt=onetimepass");
                        
                    case ("onetimepass"):
                        if (!isset ($_POST["password"])){
                            return redirect ()->to ("account");
                        }

                        $token_id = Session::get("onetime_id");
                        $email = Session::get ("email");
                        if ($token_id === false || $email === false){
                            return redirect ()->to ("account");
                        }

                        if (!OnetimePass::check ($token_id, $email, $_POST["password"])){
                            Log::info ("token:".$token_id.",email:".$email);
                            return redirect ()->to ("account?opt=onetimepass");
                        }

                        return view ("account.set_info");
                    
                    case ("set_info"):
                        if (!(isset ($_POST["name"])) && (isset ($_POST["password"]))){
                            return redirect ()->to ("account");
                        }
                        $name     = $_POST["name"];
                        $password = $_POST["password"];
                        $email    = Session::get ("email");
                        if (!Signup::setInfo ($name, $email, $password)){
                            Log::info ("Unset");
                            return redirect ()->to ("account");
                        }
                        return redirect ()->to ("account");
                }
                return view ("account.signin");
            }catch (\Exception $e){
                echo $e->getMessage();
            }
            return redirect ()->to ("account?opt=signup");
        }
        private static function setOpt () : string{
            $opt = "signin";
            if (isset ($_GET["opt"])){
                $opt = $_GET["opt"];
            }
            return $opt;
        }
        private static function setOptPost () : string{
            $opt = "signin";
            if (isset ($_POST["opt"])){
                $opt = $_POST["opt"];
            }
            return $opt;
        }
    }
?>