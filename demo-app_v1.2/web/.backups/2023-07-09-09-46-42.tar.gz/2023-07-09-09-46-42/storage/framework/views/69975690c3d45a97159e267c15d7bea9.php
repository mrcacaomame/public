<!DOCTYPE html>
<html lang = "ja">
    <head>
        <meta charset = "utf-8">
        <title>information</title>
    </head>
    <body>
        <h1>Information</h1>
        <h3>Weight: <?php echo e($weight); ?></h3>
        <h3>Height: <?php echo e($height); ?></h3>
    </body>
</html><?php /**PATH /var/www/resources/views/information.blade.php ENDPATH**/ ?>