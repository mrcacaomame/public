<?php
    namespace App\Models\Account;

    use App\Models\Mysql\Mysql;
    use App\Models\Mysql\MysqlException;
    use App\Models\Session\Session;
    use Log;

    class Signin{
        private const DB_NAME = "demo_app";
        public static function token (string $user_id, string $user_token) : bool{
            try{
                $info = new Mysql ();
                $info->autoLoad ();
                $info->connect (Signin::DB_NAME);

                $sql = "SELECT `token` FROM `users` WHERE `id`=$user_id && `del`=false LIMIT 1;";
                $query = $info->executeQuery ($sql);
                if (empty ($query)){
                    return false;
                }

                $hash = "";
                foreach ($query as $row){
                    $hash = $row[0];
                    break;
                }

                $ret = password_verify ($user_token, $hash);
                
                return $ret;
            }catch (MysqlException $e){
                Log::info ($e->getMessage ());
            }
            return false;
        }
        public static function password (string $user_id, string $user_password){
            try{
                $info = new Mysql ();
                $info->autoLoad ();
                $info->connect (Signin::DB_NAME);

                $sql = "SELECT `password` FROM `users` WHERE `id`=$user_id && `del`=false LIMIT 1;";
                $query = $info->executeQuery ($sql);
                $pass_hash = "";
                foreach ($query as $row){
                    $pass_hash = $row[0];
                }

                $password = hash ("sha512", $user_password);
                $ret = password_verify ($password, $pass_hash);

                if ($ret){
                    $token = password_hash (substr ($pass_hash, 20, 50), PASSWORD_BCRYPT);
                    $token = hash ("sha512", $token);

                    $token_hash = password_hash ($token, PASSWORD_BCRYPT);

                    $sql = "UPDATE `users` SET `token`=$token_hash WHERE `id`=$user_id LIMIT 1;";
                    if (!$info->execute ($sql)){
                        Log::info ($sql);
                    }
                    Session::set ("user_id", $user_id);
                    Session::set ("user_token", $token);
                }
                return $ret;
            }catch (MysqlException $e){
                Log::info ($e);
            }
        }
    }
?>