<!DOCTYPE html>
<html lang = "ja">
    <head>
        <meta charset = "utf-8">
        <title>information</title>
    </head>
    <body>
        <h1>Information</h1>
        <h3>Weight: {{$weight}}</h3>
        <h3>Height: {{$height}}</h3>
    </body>
</html>